# Servidor Moo-Quest autoral — escopo CORRIGIDO

O **BrowserQuest-Revived** é somente referência para operação: instalação visual no
**aaPanel**, administração autenticada, logs, backups e atualizações produzidas
pelo nosso próprio projeto. **O jogo NÃO terá NPC, missões, campanha nem
editor/modificação administrativa de mapa.** A construção de estruturas pelos
jogadores durante a partida continua fazendo parte do escopo.

## Objetivo de aceitação (não alcançado ainda)

O cliente Lua/LÖVE já implementado deve funcionar com o servidor independente
sem perder seus efeitos visuais, controles ou telas. O servidor atual não copia
bibliotecas, classes, lógica de jogadores, scripts ou artes do MooMoo.io ou
BrowserQuest. Reimplementação de formatos necessários à interoperabilidade
não equivale a autorização de distribuir artes, marca, textos e visuais
protegidos; revisão jurídica independente ainda é necessária.

### Especificação de entrada que o cliente realmente exige

- `GET /ping`: retorna JSON com `build` alfanumérico;
- `POST /api/join`: emite ticket de 36 caracteres hex e `did` hexadecimal;
- WebSocket `/s/LC?b=...&token=tk:...`, resposta `io-init` em MessagePack;
- sessão HMAC-SHA256 autenticando pacotes binários e sequência monotônica;
- envio **pelo jogador** dos códigos `M,D,9,e,F,z,H,K,L,N,b,P,Q,c,6,S,0`;
- recepção inicial de `A,C,D,H,N,V,T,U`, depois `a` (posições/atributos),
  `I` (animais), `G` (placar), `O` (saúde), `K` (golpe), `P` (morte),
  `Q,R` (remoção de construções), `5` (equipamento), `3,4` (tribos) etc.
- Conforme `src/protocol/original_crypto.lua`, o modo **unpinned** do cliente
  reconhece somente 17 comandos e 36 eventos; para perfis, anúncios e os
  efeitos adicionais (`p,F,W,m,r,q`) é necessário um modo de transporte
  completo, independentemente implementado, ou mínima adaptação de transporte
  do cliente. Não basta habilitar um nome de pacote não reconhecido.

### Estado real do novo servidor

Implementado na fundação experimental:

- infraestrutura Node.js + aaPanel, login proprietário, painel de jogadores,
  moderação, auditoria e atualização **Ed25519** com rollback;
- binário de interoperabilidade independente em `src/native-protocol.js`,
  sem depender do antigo `server/src/protocol`;
- `/ping`, `/api/join` com ticket de uso único, `/s/LC`, pacote `io-init`,
  validação HMAC/antirreplay, entrada M -> C/D e atualizações de posição;
- mundo de coordenadas contínuas 14.400, recursos de coleta e seu reaparecimento,
  fauna básica (animais sem diálogo/NPC), estruturas com custo e dano,
  espinhos, combate direcional, cura por alimento, progressão e upgrades parciais,
  vida/morte, compras limitadas e tribos básicas — decisões do servidor;
- armas de longo alcance 9/12/13/15 com requisitos de evolução e munição,
  projéteis `X`/`Y` animados pelo Lua e colisão varrida no Node contra
  jogadores, animais, obstáculos e construções; proteção da própria tribo;
- botão `F` mantido aciona disparos/coleta somente após o intervalo autorizado
  pelo servidor e o envio de `F(0)` interrompe o ataque;
- escudo de madeira (arma 11) desbloqueado aos seis níveis: defesa frontal
  calculada pelo Node contra golpes e projéteis, sem falsificar golpes de martelo;
- torre defensiva construída (item 17, índice Lua 33): custo de recursos,
  limite por jogador, identificação de hostis, proteção de aliados, cadência
  de 2200 ms, balas reais de tipo 1 e eventos `M`/`X`/`Y` para Lua;
  sem NPCs, editor, comandos gráficos ou detecção de alvos no cliente;
- novas construções e melhorias da progressão por idade no Node: armadilha
  (15, idade 4), impulsionador (16, idade 4), plataforma de cura
  (19, idade 7), bloqueador contra construções de rivais (21, idade 7)
  e moinho avançado (12, idade 8, exige moinho 11);
- a armadilha imobiliza rivais temporariamente (com recarga), a plataforma
  cura apenas o proprietário e os aliados, o impulsionador altera a velocidade
  do movimento validado pelo Node e bloqueadores não impedem sua própria tribo;
- geradores de ouro calculados pelo tempo transcorrido e não pela quantidade
  de ticks da VPS, mantendo frações e limitando acúmulo depois de travamentos;
- contagem de estruturas no pacote Lua `S` agora é por grupo de construção
  (paredes, moinhos etc.), e não por ID individual;
- minas e árvores plantadas (IDs 13/14, upgrades Lua 29/30) oferecem coleta
  em golpes autorizados pelo Node, com custos e limites por grupo;
- plataforma de renascimento (ID 20, upgrade Lua 36) marca um ponto válido de
  respawn, é consumida ao ser utilizada e envia remoção/contagem corrigida;
- teletransportador (ID 22, upgrade Lua 38) move jogadores vivos somente
  para coordenadas escolhidas e verificadas pelo servidor, com cooldown;
- remoção de construções comunica ao Lua contagem atual inclusive zero, e
  construções com custo de comida também atualizam o contador de comida;
- muralha de castelo (ID 5, upgrade Lua 21), espinhos venenosos (ID 8,
  upgrade Lua 24), espinhos giratórios (ID 9, upgrade Lua 25) e queijo
  (ID 2, upgrade Lua 18) seguem custos e pré-requisitos do catálogo;
  veneno aplica dano por segundo durante tempo limitado, com proteção de
  aliados; queijo recupera 30 pontos imediatamente e até 50 ao longo de
  cinco segundos, sem empilhamento das curas periódicas;
- coleta de minas/árvores plantadas não pode ser usada por adversários
  para gerar recursos; eles precisam destruir a estrutura, respeitando HP;
- plataforma elevada (item 18, upgrade Lua 34, idade 7) permite atravessar
  paredes próximas com janela curta calculada pelo Node; travessia de água
  e física de biomas ainda exigem validação específica com o cliente LÖVE;
- loja autoritativa com a lista de preços correspondente a todos os itens
  comercializáveis da loja Lua, incluindo os cosméticos; itens exclusivos
  (45/61) permanecem indisponíveis para compra;
- efeitos selecionados de capacetes e acessórios no Node: velocidade e
  defesa, custo e alcance de projéteis, bônus de coleta, imunidade ao veneno,
  proteção contra projéteis, autorregeneração, ouro passivo e evasão de torres;
  demais efeitos especiais ainda precisam de implementação e testes;
- Contas de jogadores com credenciais scrypt, sessão Redis e armazenamento
  PostgreSQL de inventário, recursos, XP, progressão, equipamentos e cosméticos;
  recuperação apenas com token autenticado e ticket vinculado, nunca por did;
- Primeira fase de construções persistentes por personagem registrado:
  objetos salvos com HP, restaurados com limites/colisão; desaparecem offline;
- Clãs registrados persistem em tabelas próprias PostgreSQL, com único dono
  autenticado, associação de membros e nome reservado durante desconexão;
  convidados mantêm somente clãs transitórios; transferência de propriedade,
  gestão avançada e interação offline permanecem pendentes;
- Integração da autenticação na UI LÖVE ainda pendente;
- PostgreSQL obrigatório para o estado administrativo durável; Redis obrigatório\n  para sessões, limitação de login e tickets de entrada de uso único. O estado\n  em tempo real da partida permanece em RAM; não há ainda persistência de contas\n  de jogadores, inventários ou construções entre reinicializações;\n- testes unitários de codecs, entrada, inventário, compras, construção,
  recursos, retorno após coleta, cura, XP e escolhas de equipamentos. O teste
  WebSocket de ponta a ponta inclui loja, cura e upgrades, além da entrada.
  A confirmação visual na versão Windows ainda está pendente.

**Não comprovado:** conexão efetiva com o aplicativo LÖVE em Windows;
compatibilidade integral de todos os comandos, cosméticos, equipamentos,
animações, colisão e câmera. O antigo pacote de artes do cliente ainda
precisa de auditoria/recriação licenciada antes de lançamento comercial.

### Pendências obrigatórias (não declarar concluído antes delas)

1. Rodar o teste **WebSocket real** com dependência `ws` instalada, mais o
   cliente Lua/LÖVE no Windows, provando `M -> C/D -> movimento -> coleta`.
2. Implementar os recursos, animais existentes, obstáculos, objetos e biomas
   requeridos pelo cliente, sem introduzir NPCs ou editores de mapa.
3. Completar os equipamentos e efeitos restantes: já há arco, escudo, torres,
   armadilha, impulso, cura, bloqueio de construções, moinhos, minas/árvores
   plantadas, teletransporte e reaparecimento em construção, mas ainda faltam
   demais variantes, itens e efeitos (inclusive cosméticos), testes de colisão
   e verificação visual do movimento/teletransporte no LÖVE real.
   Não assumir paridade só porque os pacotes `X`/`Y` passaram na CI.
4. Morte/renascimento, clãs, loja, chat, placar, perfil e moderação no Node,
   usando confirmações autoritativas; testes para manipulação de pacotes,
   replay, fraude de posição e execução simultânea de 40 jogadores.
5. Completar os pacotes estendidos de aviso e efeitos; cobertura 100% do
   contrato consumido pelo `World:apply` do Lua.
6. aaPanel: backup/restore verificado, atualização assinada e rollback real,
   contas persistentes, auditoria de permissões e proteção da API de ingresso.
7. Testar Linux/Windows lado a lado, paridade funcional/visual e carga.
8. Revisão jurídica de marcas, artes do cliente, nomes, arquivos, licenças,
   pacote distribuído e limites da engenharia de interoperabilidade.

**O painel e o atualizador não tornam o jogo completo por si mesmos.**
Nenhum código do servidor antigo deve entrar no pacote comercial V2.

## Fase de variantes e status (22/10/2026)
- Gold: +10% dano corpo a corpo; Diamond/Ruby: +18%.
- Ruby: 5 de veneno por segundo por 5 segundos; Devils Tail: 4 de
  sangramento por segundo por 2 segundos, somente após dano real.
- Imunidade a veneno é validada no Node. Reaplicação não acumula pulsos
  nem troca um efeito mais forte por outro mais fraco.
- Kills causadas por dano periódico são creditadas uma única vez.
- Emerald continua bloqueada sem autenticação de membresia; não está
  habilitada para o jogador comum.
- Teste: test/weapon-variants-status.test.js. Ainda faltam Crab King,
  transporte de eventos especiais no Lua e validação presencial Windows.

## Região secreta e Crab King (22/10/2026)

- Acesso pelo corredor a oeste do rio com limites derivados da geometria
  das piscinas secretas da referência; barreiras preservam o mapa normal.
- Crab King no local (-2500,7200), estados surface/dive/submerged/emerge;
  imunidade a golpes e projéteis enquanto mergulhado/submerso.
- Ataques SLAM/GEYSER/CLAW/SPLASH telegrafados com aviso antecipado.
  Dano, knockback e mortes processados pelo Node; o Lua só renderiza.
- Evento W adicionado como extensão no final da tabela de transporte V2,
  sem modificar os IDs aleatorizados existentes.
- Ainda exige conferência visual real no LÖVE, ajustes finos de IA e de
  física das bordas secretas; não representa paridade final.

## Capacidade negociada para efeitos especiais (22/10/2026)

Clientes V2 novos anunciam `Y(1)` após `io-init`, antes de `M`. Somente
essas conexões recebem o aviso visual `W` do Crab King. Um cliente Lua V2
antigo não entende `W` e seria desconectado se o servidor enviasse o evento
sem negociação. As tabelas de IDs embaralhados originais permanecem intactas:
`Y` é uma extensão com ID 18, `W` é a extensão de recepção com ID 38.
Essa negociação não confere privilégios nem altera o estado de jogo.
