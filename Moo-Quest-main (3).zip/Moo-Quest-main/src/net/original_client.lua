-- DIRECT client of the original al007ex/moomoo-clone WebSocket endpoint.
-- The reconstructed Node game logic is unchanged (a missing local config
-- file can be added by the Windows installer). No custom TCP gateway.
-- Uses the original /api/join ticket, pinned authenticated transport, and
-- original spawn messages. Browser-specific bundle seal still unsupported.
local SocketWS=require("src.net.websocket_client")
local Bootstrap=require("src.protocol.bootstrap")
local Random=require("src.net.secure_random")
local Build=require("src.protocol.original_build")
local OriginalSession=require("src.protocol.original_session")
local V2Session=require("src.protocol.v2_session")
local Join=require("src.net.original_join")
local MessagePack=require("src.protocol.msgpack")
local Original={}
Original.__index=Original

local function validHost(h)
  return type(h)=="string" and h:match("^[%w%.%-]+$")~=nil
end
local function validPort(n)
  return type(n)=="number" and n>=1 and n<=65535 and n%1==0
end
local function httpPing(socketHttp,host,port)
  local oldTimeout=socketHttp.TIMEOUT
  socketHttp.TIMEOUT=2
  local ok,data,code=pcall(socketHttp.request,
    "http://"..host..":"..port.."/ping")
  socketHttp.TIMEOUT=oldTimeout
  if not ok then return nil,"GET /ping falhou: "..tostring(data) end
  if tonumber(code)~=200 then return nil,"GET /ping HTTP "..tostring(code) end
  if type(data)~="string" or #data>32768 then return nil,"resposta /ping invalida" end
  local build=data:match('"build"%s*:%s*"([%w]+)"')
  if not build or #build>100 then return nil,"identificador do build ausente no /ping" end
  return build
end
function Original.new(options)
  options=options or {}
  local socketHttp=options.http or require("socket.http")
  return setmetatable({
    host=options.host or "127.0.0.1",port=options.port or 8080,
    server=options.server or "LC",
    name=options.name or "Jogador",
    autoSpawn=options.autoSpawn~=false,
    authToken=options.authToken,
    authRefresh=options.authRefresh,
    expectedBuild=options.expectedBuild,
    nativeSession=options.nativeSession==true,
    join=options.join or Join,
    ltn12=options.ltn12,
    did=nil,ticket=nil,spawnSent=false,sid=nil,packetCount=0,
    http=socketHttp,random=options.random or Random.bytes,
    sha1=options.sha1 or function(data) return love.data.hash("sha1",data) end,
    socketLib=options.socket,
    state="idle",status=options.nativeSession and "Servidor V2 ainda nao conectado." or "Servidor original ainda nao conectado.",
    error=nil,build=nil,handshake=nil,session=nil,websocket=nil,events={}
  },Original)
end
function Original:connect()
  if not validHost(self.host) or not validPort(self.port) then
    self.state="failed";self.error="Endereco local invalido"
    return false,self.error
  end
  if not self.server:match("^[%w]+$") then
    self.state="failed";self.error="Servidor de jogo invalido"
    return false,self.error
  end
  self:close()
  local build,reason=httpPing(self.http,self.host,self.port)
  if not build then
    self.state="failed";self.error=reason
    self.status=(self.nativeSession and "Servidor V2 indisponivel: " or "Servidor original indisponivel: ")..reason
    return false,reason
  end
  if self.expectedBuild and build~=self.expectedBuild then
    self.state="failed"
    self.error="Servidor inesperado: esperado build "..self.expectedBuild..", recebido "..build
    self.status=self.error
    return false,self.error
  end
  self.build=build
  -- /api/join is the exact API used by the author's local client. Its guest
  -- CAPTCHA is an explicit local stand-in (boolean), not an internet service.
  -- One fresh, single-use ticket is required for every WebSocket attempt.
  local function requestTicket()
    return self.join.guest({
      host=self.host,port=self.port,server=self.server,did=self.did,
      authToken=self.authToken,
      http=self.http,ltn12=self.ltn12
    })
  end
  local grant,joinError,httpStatus=requestTicket()
  -- V2 access tokens expire after 8h. Only an explicit 401 from the
  -- account-bound admission endpoint may trigger ONE refresh+retry.
  -- Never retry arbitrary HTTP failures or a refused guest CAPTCHA.
  if not grant and self.nativeSession and self.authToken and httpStatus==401
    and type(self.authRefresh)=="function" then
    local refreshed,refreshError=self.authRefresh()
    if refreshed and type(refreshed.token)=="string" then
      self.authToken=refreshed.token
      grant,joinError,httpStatus=requestTicket()
    else
      joinError="Sessao V2 expirada: "..tostring(refreshError or "entre na conta novamente")
    end
  end
  if not grant then
    self.state="failed"
    self.error=joinError
    self.status="Servidor recusou ingresso: "..tostring(joinError)
    return false,joinError
  end
  self.ticket=grant.ticket
  self.did=grant.did
  self.spawnSent=false
  self.sid=nil
  self.packetCount=0
  local options={secureRandom=self.random,sha1=self.sha1}
  if self.socketLib then options.socket=self.socketLib end
  local ws=SocketWS.new(options)
  -- Keep ?b= bound to /ping and supply the authentic one-use join ticket.
  -- ?u= is needed only when the optional official JS bundle exists; the
  -- Lua client does not impersonate or copy the official browser bundle.
  local path="/s/"..self.server.."?b="..build.."&token=tk:"..grant.ticket
  local ok,err=ws:connect(self.host,self.port,path)
  if not ok then
    self.state="failed";self.error=err
    self.status=(self.nativeSession and "Falha no WebSocket V2: " or "Falha no WebSocket original: ")..tostring(err)
    return false,err
  end
  self.websocket=ws
  self.state="connecting"
  self.error=nil
  self.status=self.nativeSession and "Ticket V2 emitido; abrindo WebSocket local..." or
    "Ticket guest original emitido; abrindo WebSocket em localhost..."
  -- Do not print URLs containing the secret single-use ticket.
  return true
end
function Original:update()
  local ws=self.websocket
  if not ws then return end
  ws:update()
  for _,evt in ipairs(ws:drain()) do
    if evt.kind=="open" then
      self.state="waiting_handshake"
      self.status=self.nativeSession and "WebSocket V2 aberto; aguardando io-init..." or
        "WebSocket original aberto; aguardando io-init..."
    elseif evt.kind=="binary" then
      if not self.handshake then
        local handshake,err=Bootstrap.decodeHandshake(evt.value)
        if not handshake then
          self.state="failed"
          self.error="Handshake original invalido: "..tostring(err)
          self.status=self.error
          ws:close()
        else
          self.handshake=handshake
          self.state="handshake_received"
          self.events[#self.events+1]={kind="io-init",data=handshake}
          local params,buildError=Build.load(self.build)
          if handshake.pinned and not params then
            self.state="blocked"
            self.error=tostring(buildError)
            self.status="Build do protocolo indisponivel: "..self.error
          elseif handshake.pinned and params.buildId~=self.build then
            self.state="blocked"
            self.status="Build local diferente do servidor remoto; parametros rejeitados."
          else
            local sessionFactory=self.nativeSession and V2Session or OriginalSession
            local session,sessionError=sessionFactory.new(handshake,params,
              function(data) return love.data.hash("sha256",data) end)
            if not session then
              self.state="blocked"
              self.status="Sessao original indisponivel: "..tostring(sessionError)
            else
              self.session=session
              self.state="keyed_transport"
              self.status=self.nativeSession and "Sessao V2 autenticada; aguardando Play." or
                "Handshake original aceito; aguardando Play no cliente Lua."
              -- Do not advertise the optional Y extension on connection.
              -- Older deployed V2 servers reject unknown extension packets
              -- with WebSocket 1008 invalid_packet before the player clicks Play.
              -- Without Y, the server keeps legacy-compatible event encoding.
              if self.autoSpawn then
                local okSpawn,spawnErr=self:spawn()
                if not okSpawn then
                  self.state="failed"
                  self.error="Spawn nao enviado: "..tostring(spawnErr)
                  self.status=self.error
                end
              end
            end
          end
        end
      elseif self.session then
        local packet,err=self.session:decode(evt.value)
        if not packet then
          self.state="failed"
          self.error=tostring(err)
          self.status="Erro no pacote do servidor original: "..self.error
          ws:close()
        else
          self.packetCount=self.packetCount+1
          self.events[#self.events+1]={kind="game_packet",data=packet}
          if packet.name=="q" and self.session then
            local salt=packet.args[1]
            local probes=packet.args[2]
            -- The local original-server compatibility config sends zero
            -- browser-specific probes. Answer an EMPTY round accurately;
            -- do not pretend a Lua client passed browser integrity probes.
            if type(salt)=="number" and type(probes)=="table"
              and #probes==0 and self.session.sealMode==0 then
              local seq=self.session.sent
              local ledger=self.session.ledger
              local valid,why=self:send("T",{
                0,0,0,MessagePack.null,salt,seq,ledger
              })
              if not valid then
                self.status="Falha ao responder telemetria original: "..tostring(why)
              end
            else
              self.status="Servidor exige probes/selagem do navegador ainda nao implementados em Lua."
              self.state="blocked"
            end
          end
          if packet.name=="C" and type(packet.args[1])=="number" then
            self.sid=packet.args[1]
            self.state="spawn_confirmed"
            self.status=(self.nativeSession and "Spawn confirmado no Node V2! ID " or
              "Spawn confirmado pelo servidor Node original! ID ")..tostring(self.sid)
          elseif packet.name=="B" then
            self.status="Servidor enviou desconexao: "..tostring(packet.args[1])
          end
        end
      else
        self.events[#self.events+1]={kind="encrypted_frame",length=#evt.value}
      end
    elseif evt.kind=="close" then
      self.state="closed"
      local raw=evt.value
      local code=type(raw)=="string" and #raw>=2 and (raw:byte(1)*256+raw:byte(2)) or nil
      local descriptions={
        [4001]="ticket, banimento, limite de conexoes ou politica do servidor",
        [4002]="versao do build ou bundle nao corresponde ao servidor",
        [4003]="servidor exige conta autenticada",
        [4004]="origem WebSocket nao aceita"
      }
      local reason=type(raw)=="string" and #raw>2 and raw:sub(3) or nil
      if reason and (#reason>120 or reason:find("[%c]")) then reason=nil end
      local policyReasons={
        invalid_packet="pacote do cliente recusado pelo protocolo V2",
        rate_limit="limite de mensagens por segundo",
        account_in_use="esta conta ja possui uma partida aberta",
        unknown_account="conta nao encontrada no banco de dados",
        bad_spawn="dados de entrada na partida invalidos",
        guests_disabled="servidor nao permite convidados",
        session_revoked="sessao encerrada pelo servidor",
        packet_error="erro ao codificar resposta do servidor"
      }
      local description=(reason and (policyReasons[reason] or reason))
        or (code and descriptions[code])
        or (code==1008 and "politica de acesso recusou a conexao (motivo nao enviado)")
        or "conexao encerrada"
      local serverLabel=self.nativeSession and "Servidor V2" or "Servidor original"
      self.status=serverLabel.." fechou WebSocket: "..(code and tostring(code) or "?").." - "..description
      self.error=self.status
    elseif evt.kind=="error" then
      self.state="failed"
      self.error=tostring(evt.value)
      self.status=(self.nativeSession and "Falha WebSocket V2: " or
        "Erro no WebSocket original: ")..self.error
    end
  end
  if ws.state=="closed" and self.state~="closed" and self.state~="failed" then
    self.state="closed"
    self.status="Conexao original fechada antes de entrar no jogo."
  end
end
-- The reference browser connects first and sends M only after Play.
-- Existing old callers preserve autoSpawn=true by default.
function Original:spawn(profile)
  if self.spawnSent and self.state~="spawn_confirmed" then
    return false,"spawn already requested"
  end
  if not self.session or not self.websocket or self.websocket.state~="open" then
    return false,"servidor ainda nao concluiu o handshake autenticado"
  end
  profile=profile or {}
  local name=type(profile.name)=="string" and profile.name or self.name
  local skin=type(profile.skin)=="number" and math.floor(profile.skin) or 0
  skin=math.max(0,math.min(9,skin))
  local request=MessagePack.map({
    name=name:sub(1,15),
    moofoll=profile.moofoll==true,
    skin=skin,
    anon=profile.anon==true
  })
  local success,err=self:send("M",{request})
  if success then
    self.name=name
    self.spawnSent=true
    self.state="joining"
    self.status="Entrada solicitada ao Node; aguardando confirmacao C..."
  end
  return success,err
end
function Original:send(name,args)
  if not self.session or not self.websocket or self.websocket.state~="open" then
    return false,"original session not authenticated"
  end
  local frame,err=self.session:encode(name,args)
  if not frame then return false,err end
  return self.websocket:send(frame,2)
end
function Original:drain()
  local events=self.events
  self.events={}
  return events
end
function Original:close()
  if self.websocket then self.websocket:close() end
  self.websocket=nil
  self.handshake=nil
  self.session=nil
  self.spawnSent=false
  self.ticket=nil
  self.events={}
end
return Original
